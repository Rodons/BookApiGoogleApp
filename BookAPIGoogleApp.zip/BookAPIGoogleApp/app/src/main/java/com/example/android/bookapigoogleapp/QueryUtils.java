package com.example.android.bookapigoogleapp;

/**
 * Created by Mr X on 17/06/2017.
 */

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper methods related to requesting and receiving book data from Google API.
 */

public final class QueryUtils {

    /**
     * Tag for the log messages
     */
    private static final String LOG_TAG = MainActivity.class.getName();

    /**
     * Create a private constructor because no one should ever create a {@link QueryUtils} object.
     * This class is only meant to hold static variables and methods, which can be accessed
     * directly from the class name QueryUtils (and an object instance of QueryUtils is not needed).
     */
    private QueryUtils() {
    }

    /**
     * Query the Google Book API dataset and return a list of {@link Book} objects.
     */
    public static List<Book> fetchBookData(String requestUrl) {
        // Create URL object
        URL url = createUrl(requestUrl);

        // Perform HTTP request to the URL and receive a JSON response back
        String jsonResponse = null;
        try {
            //Try to make an HTTP Request with the created URL
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {
            //If it fails, log it
            Log.e(LOG_TAG, "Problem making the HTTP request.", e);
        }

        // Extract relevant fields from the JSON response and create a list of {@link Book}s
        List<Book> books = extractFeatureFromJson(jsonResponse);

        // Return the list of {@link Earthquake}s
        return books;
    }

    /**
     * Returns new URL object from the given string URL.
     */
    private static URL createUrl(String querydata) {
        //Create a variable for the URL
        URL url = null;

        try {
            //Put the search term given by the user into a GoogleBooks API-standarded request URL
            // and create a URL from it
            url = new URL("https://www.googleapis.com/books/v1/volumes?q=intitle:" + querydata + "&maxResults=10");
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Problem building the URL ", e);
        }
        return url;
    }


    /**
     * Make an HTTP request to the given URL and return a String as the response.
     */
    private static String makeHttpRequest(URL url) throws IOException {
        //Create a variable for the response
        String jsonResponse = "";

        // If the URL is null, then return early.
        if (url == null) {
            return jsonResponse;
        }

        //Create a variable for the connection and the InputStream
        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;

        try {

            //Try to create a request with the created URL and the settings below and connect
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(13000 /* milliseconds */);
            urlConnection.setConnectTimeout(15000 /* milliseconds */);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            // If the request was successful (response code 200),
            // then read the input stream and parse the response.
            if (urlConnection.getResponseCode() == 200) {

                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {

                Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
            }
        } catch (IOException e) {

            //If it fails, log it
            Log.e(LOG_TAG, "Problem retrieving the earthquake JSON results.", e);
        } finally {

            //If the connection is on yet and the InputStream is open yet, disconnect and close the InputStream
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {
                // Closing the input stream could throw an IOException, which is why
                // the makeHttpRequest(URL url) method signature specifies than an IOException
                // could be thrown.
                inputStream.close();
            }
        }
        return jsonResponse;
    }

    /**
     * Convert the {@link InputStream} into a String which contains the
     * whole JSON response from the server.
     */
    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();

        if (inputStream != null) {

            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);

            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }


    /**
     * Return a list of {@link Book} objects that has been built up from
     * parsing the given JSON response.
     */
    private static List<Book> extractFeatureFromJson(String bookJSON) {
        // If the JSON string is empty or null, then return early.
        if (TextUtils.isEmpty(bookJSON)) {
            return null;
        }

        // Create an empty ArrayList that we can start adding books to
        List<Book> books = new ArrayList<>();

        // Try to parse the JSON response string. If there's a problem with the way the JSON
        // is formatted, a JSONException exception object will be thrown.
        // Catch the exception so the app doesn't crash, and print the error message to the logs.
        try {

            // Create a JSONObject from the JSON response string
            JSONObject baseJsonResponse = new JSONObject(bookJSON);

            // Extract the JSONArray associated with the key called "features",
            // which represents a list of features (or books).
            JSONArray bookArray = baseJsonResponse.getJSONArray("features");

            // For each book in the bookArray, create an {@link Book} object
            for (int i = 0; i < bookArray.length(); i++) {

                // Get a single book at position i within the list of books
                JSONObject currentBook = bookArray.getJSONObject(i);

                // For a given book, extract the JSONObject associated with the
                // key called "properties", which represents a list of all properties
                // for that book.
                JSONObject properties = currentBook.getJSONObject("propertiesInfo");

                String title = properties.getString("title");
                String author;
                if (properties.has("authors")) {
                    author = properties.getJSONArray("authors").get(0).toString();
                }
                else {
                    author = "Unknown author";
                }
                String link = properties.getString("infoLink");

                String imgUrlString;
                Bitmap cover;
                if (properties.has("imageLinks")) {
                    JSONObject imageObject = properties.getJSONObject("imageLinks");
                    imgUrlString = imageObject.getString("thumbnail");
                    URL imgUrl = createUrl(imgUrlString);
                    cover = BitmapFactory.decodeStream(imgUrl.openConnection().getInputStream());
                } else {
                    cover = null;
                }



                //Create a new Book Object with the data of a given book
                Book book = new Book(author, title, link, cover);

                //Add the book to the List of Book Objects
                books.add(book);
            }

        } catch (JSONException e) {

            //If it fails, log it
            Log.e(LOG_TAG, "Error extracting the data from the JSON response", e);
        } catch (IOException e) {
        Log.e("QueryUtils", "Problem parsing image url link", e);
    }

        return books;
    }


}
